package ru.leonov;

public class Main {

    public static void main(String[] args) {
        System.out.printf("=========== Task3.1 Преобразование массива в списки  ===========%n");
        Task3_1.Task();

        System.out.printf("=========== Task3.2 Работа со списками ===========%n");
        Task3_2.Task();

        System.out.printf("=========== Task3.3 Односвязанный список ===========%n");
        Task3_3.Task();

        System.out.printf("=========== Task3.4 2х связанный список ===========%n");
        Task3_4.Task();

        System.out.printf("=========== Task3.5 Iterator ===========%n");
        Task3_5.Task();
    }
}
